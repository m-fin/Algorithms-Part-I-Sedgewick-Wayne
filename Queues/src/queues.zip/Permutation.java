public class Permutation {

}
